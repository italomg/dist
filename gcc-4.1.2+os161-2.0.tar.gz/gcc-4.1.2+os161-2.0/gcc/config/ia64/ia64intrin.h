/* Overloaded builtins have been ported to C++: nothing is needed
   in the header anymore.  This file intentionally left void.  */

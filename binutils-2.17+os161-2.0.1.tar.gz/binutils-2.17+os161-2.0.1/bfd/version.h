#define BFD_VERSION_DATE 20060623
#define BFD_VERSION @bfd_version@
#define BFD_VERSION_STRING @bfd_version_string@

extern u_int32_t bus_ramsize;
extern char *ram;

